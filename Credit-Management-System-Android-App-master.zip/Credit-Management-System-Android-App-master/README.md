# Credit-Management-System-Android-App

## Installation guide:

1) Download the project and open it using Android Studio.

2) Goto firebase.io and create a new project under th name of your choice.

3) Now integrate the firebase project with this project using Android Studio. You can also integrate manually by downloading the google-service.json file from the firebase project and add that file in this project.

4) That it.

## Screenshots:

<br />

> **_NOTE:_**  Please find complete screenshots in [Screenshots](https://github.com/areebmomin/Credit-Management-System-Android-App/tree/master/Screenshots) folder.

<br />

![alt text](https://github.com/areebmomin/Credit-Management-System-Android-App/blob/master/Screenshots/Screenshot_2020-03-15-17-50-55-951_com.test.creditinfo.png?raw=true)


![alt text](https://github.com/areebmomin/Credit-Management-System-Android-App/blob/master/Screenshots/Screenshot_2020-03-15-17-51-08-257_com.test.creditinfo.png?raw=true)


![alt text](https://github.com/areebmomin/Credit-Management-System-Android-App/blob/master/Screenshots/Screenshot_2020-03-15-18-02-24-554_com.test.creditinfo.png?raw=true)
